object Problem {
  def divisors(n: Int) = (1 to n).filter(n % _ == 0).toSet

  def divisorsOfAll(numbers: Set[Int]) : Set[Int] = ... foldLeft ...
}
