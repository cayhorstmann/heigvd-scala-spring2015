object Problem {
  def divisors(n: Int) = (1 to n).filter(n % _ == 0).toSet

  def divisorsOfAny(numbers: Set[Int]) : Set[Int] = ... flatMap ...
}
