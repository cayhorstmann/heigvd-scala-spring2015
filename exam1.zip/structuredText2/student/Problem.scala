case class Text ... {
  ...
}
    
case class Elem ... {
  ...
}

