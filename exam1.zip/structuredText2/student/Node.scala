abstract class Node {
  def toXML2: String;
}
