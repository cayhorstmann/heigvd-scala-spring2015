object Tester extends App {
val f = Problem.genericDoThisAndMaybeThat(
  (s: String) => s.replace("a", ""))(s => s.length <= 5)(s => s.toUpperCase)
  println(f("macadamia"))
  println("Expected: MCDMI")
  println(f("mustard"))
  println("Expected: mustrd")

  class Person(val name: String) {
  	override def toString = s"Person(${name})"
  }
  class Student(name: String) extends Person(name) {
  	override def toString = s"Student(${name})"
  }
 
  val f2 = Problem.genericDoThisAndMaybeThat((s: String) => new Person(s))(p => p.name.contains("a"))(p => new Student(p.name))

  println(f2("Sally"))
  println("Expected: Student(Sally)")
  println(f2("Fred"))
  println("Expected: Person(Fred)")

  val f3 = Problem.genericDoThisAndMaybeThat((x: Int) => Seq(1, x))(p => p(1) == 2)(p => 1 to 2)

  println(f3(2))
  println("Expected: Range(1, 2)")
  println(f3(3))
  println("Expected: List(1, 3)")
}
