object Problem {
   def genericDoThisAndMaybeThat[A, ..., ...] (f1: A => B 
     f2: ... => Boolean 
     f3: ... => C) = ... // body should be the same as in part a
}
