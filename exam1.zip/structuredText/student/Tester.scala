object Tester extends App {
  val sample1 = Elem("body", List(Text("Hello, World")))

  println(sample1.toXML)
  println("Expected: <body>Hello, World</body>")

  val sample2 = Elem("body", List(Text("Goodbye "), Elem("b", List(Text("cruel"))), Text(" World")))

  println(sample2.toXML)
  println("Expected: <body>Goodbye <b>cruel</b> World</body>")
}
