object Tester extends App {
val f = Problem.doThisAndMaybeThat(
  s => s.replace("a", ""),
  s => s.length <= 5,
  s => s.toUpperCase)
  println(f("macadamia"))
  println("Expected: MCDMI")
  println(f("mustard"))
  println("Expected: mustrd")

val f2 = Problem.doThisAndMaybeThat(
  s => s.replace("m", ""),
  s => s.length <= 6,
  s => s.toUpperCase)
  println(f2("macadamia"))
  println("Expected: acadaia")
  println(f2("mustard"))
  println("Expected: USTARD")
}
