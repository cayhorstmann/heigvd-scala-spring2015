object Tester extends App {
  println(Problem.result2)
  println(Problem.result2 == Map("SCALA" -> Set("Portman", "Winslet", "Pitt", "Hanks", "Cage"), "POO" -> Set("Winslet", "Kidman", "Cage", "Hanks", "Pitt"))      
)
  println("Expected: true")
}
