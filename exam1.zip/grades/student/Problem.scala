object Problem {

  case class Student(studentId: Int, name: String, firstname: String)
  case class Grade(studentId: Int, courseId: String, grade: Int)

  val students :Set[Student] = Set(
    Student(1, "Pitt", "Brad"),
    Student(2, "Cage", "Nicolas"),
    Student(3, "Winslet", "Kate"),
    Student(4, "Hanks", "Tom"),
    Student(5, "Dicaprio", "Leonard"),
    Student(6, "Portman", "Nathalie"),
    Student(7, "Kidman", "Nicole")  
  )

  val grades :Set[Grade] = Set(
    Grade(1, "SCALA", 5),
    Grade(2, "SCALA", 4),
    Grade(3, "SCALA", 6),
    Grade(4, "SCALA", 3),
    Grade(6, "SCALA", 1),
    Grade(1, "POO", 4),
    Grade(2, "POO", 6),
    Grade(3, "POO", 3 ),
    Grade(4, "POO", 4),
    Grade(7, "POO", 4)
  )
  
  val result = for (... <- ...; ...) yield ...
}
