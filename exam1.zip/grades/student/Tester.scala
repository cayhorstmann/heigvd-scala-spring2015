object Tester extends App {
  println(Problem.result == Set(("Cage","SCALA",4), ("Kidman","POO",4), ("Portman","SCALA",1), ("Cage","POO",6), ("Hanks","SCALA",3), ("Pitt","SCALA",5), ("Winslet","POO",3), ("Pitt","POO",4), ("Winslet","SCALA",6), ("Hanks","POO",4)))
  println("Expected: true")
}
